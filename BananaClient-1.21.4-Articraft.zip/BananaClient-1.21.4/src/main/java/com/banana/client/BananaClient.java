package com.banana.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import org.lwjgl.glfw.GLFW;

public class BananaClient implements ClientModInitializer {
    public static boolean xray = false;
    public static boolean playerEsp = false;
    public static boolean killaura = false;
    public static boolean triggerbot = false;
    public static boolean blockEsp = false;
    public static boolean entityEsp = false;
    public static boolean fpsBoost = false;

    private static KeyBinding menuKey;
    private static int attackTimer = 0;

    @Override
    public void onInitializeClient() {
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.bananaclient.menu",
                InputUtil.Type.KEY_SYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "category.bananaclient"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (menuKey.wasPressed()) {
                client.setScreen(new BananaClickGui());
            }

            if (killaura && client.player != null && client.world != null) {
                attackTimer++;
                if (attackTimer >= 10) {
                    attackTimer = 0;
                    for (Entity entity : client.world.getEntities()) {
                        if (entity instanceof PlayerEntity && entity != client.player) {
                            double distance = client.player.distanceTo(entity);
                            if (distance <= 4.0) {
                                client.interactionManager.attackEntity(client.player, entity);
                                client.player.swingHand(Hand.MAIN_HAND);
                                break;
                            }
                        }
                    }
                }
            }
        });
    }
}
