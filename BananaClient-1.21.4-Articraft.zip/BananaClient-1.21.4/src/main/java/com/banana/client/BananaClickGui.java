package com.banana.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class BananaClickGui extends Screen {
    public BananaClickGui() {
        super(Text.literal("BananaClient ClickGUI"));
    }

    @Override
    protected void init() {
        int centerX = this.width / 2 - 100;
        int startY = this.height / 2 - 110;

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Xray: " + (BananaClient.xray ? "§aON" : "§cOFF")),
                button -> {
                    BananaClient.xray = !BananaClient.xray;
                    button.setMessage(Text.literal("Xray: " + (BananaClient.xray ? "§aON" : "§cOFF")));
                }).dimensions(centerX, startY, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Player ESP: " + (BananaClient.playerEsp ? "§aON" : "§cOFF")),
                button -> {
                    BananaClient.playerEsp = !BananaClient.playerEsp;
                    button.setMessage(Text.literal("Player ESP: " + (BananaClient.playerEsp ? "§aON" : "§cOFF")));
                }).dimensions(centerX, startY + 24, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Killaura (Safe): " + (BananaClient.killaura ? "§aON" : "§cOFF")),
                button -> {
                    BananaClient.killaura = !BananaClient.killaura;
                    button.setMessage(Text.literal("Killaura (Safe): " + (BananaClient.killaura ? "§aON" : "§cOFF")));
                }).dimensions(centerX, startY + 48, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Triggerbot: " + (BananaClient.triggerbot ? "§aON" : "§cOFF")),
                button -> {
                    BananaClient.triggerbot = !BananaClient.triggerbot;
                    button.setMessage(Text.literal("Triggerbot: " + (BananaClient.triggerbot ? "§aON" : "§cOFF")));
                }).dimensions(centerX, startY + 72, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Block ESP: " + (BananaClient.blockEsp ? "§aON" : "§cOFF")),
                button -> {
                    BananaClient.blockEsp = !BananaClient.blockEsp;
                    button.setMessage(Text.literal("Block ESP: " + (BananaClient.blockEsp ? "§aON" : "§cOFF")));
                }).dimensions(centerX, startY + 96, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("Entity ESP: " + (BananaClient.entityEsp ? "§aON" : "§cOFF")),
                button -> {
                    BananaClient.entityEsp = !BananaClient.entityEsp;
                    button.setMessage(Text.literal("Entity ESP: " + (BananaClient.entityEsp ? "§aON" : "§cOFF")));
                }).dimensions(centerX, startY + 120, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                Text.literal("FPS Boost: " + (BananaClient.fpsBoost ? "§aON" : "§cOFF")),
                button -> {
                    BananaClient.fpsBoost = !BananaClient.fpsBoost;
                    button.setMessage(Text.literal("FPS Boost: " + (BananaClient.fpsBoost ? "§aON" : "§cOFF")));
                }).dimensions(centerX, startY + 144, 200, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 135, 0xFFA500);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPauseWhenBlurred() {
        return false;
    }
}
